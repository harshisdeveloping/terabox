<h1 align="center" id="title">Terabox Downloader Bot</h1>

<p align="center"><img src="https://socialify.git.ci/MaviMods/terabox-bot/image?description=1&font=KoHo&forks=1&issues=1&language=1&name=1&owner=1&pattern=Circuit%20Board&pulls=1&stargazers=1&theme=Dark" alt="project-image"></p>

<p id="description">A telegram bot for downloading terabox videos fastly</p>

<h2>💀 Features</h2>

Here're some of the project's best features:

- 2 hours of wait time
- 1 minute anti spam
- Download videos fastly

Use at own risk. I am not responsible for break of any Terms and conditions of any companies and businesses.
